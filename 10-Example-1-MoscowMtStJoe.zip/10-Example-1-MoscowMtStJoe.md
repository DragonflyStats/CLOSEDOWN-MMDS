
Mountain St. Joe Woodlands
==============================
To further illustrate the tools in yaImpute we present a preliminary analysis of the Moscow
Mountain St. Joe Woodlands (Idaho, USA) data, originally published by Hudak et 
al. (2006). 


```R
install.packages(c("yaImpute","fastICA"))
library(yaImpute)
library(fastICA)

suppressWarnings(library(randomForest))
suppressWarnings(library(dplyr))
suppressWarnings(library(magrittr))


```

    Installing packages into '/home/nbcommon/R'
    (as 'lib' is unspecified)



```R
data(MoscowMtStJoe)
```


```R
dim(MoscowMtStJoe)

```


<ol class="list-inline">
	<li>165</li>
	<li>64</li>
</ol>



### Analysis

The analysis is broken into two major steps. 

First, the reference observations are analyzed using several different 
methods, the results compared, and a model (method) is selected.

Second, imputations are made using ASCII grid map data as input and the maps 
are displayed.Note that these data are actively being analyzed by the research 
team that collected the data and this example is not intended to be a final 
result.



```R
x <- MoscowMtStJoe[, c("EASTING", "NORTHING", "ELEVMEAN", "SLPMEAN", "ASPMEAN", "INTMEAN", "HTMEAN", "CCMEAN")]
x[, 5] <- (1 - cos((x[, 5] - 30) * pi/180))/2
names(x)[5] = "TrASP"


```


```R
y <- MoscowMtStJoe[, c(1, 9, 12, 14, 18)]

```


```R
head(x,3)
```


<table>
<thead><tr><th>EASTING</th><th>NORTHING</th><th>ELEVMEAN</th><th>SLPMEAN</th><th>TrASP</th><th>INTMEAN</th><th>HTMEAN</th><th>CCMEAN</th></tr></thead>
<tbody>
	<tr><td>571920.0 </td><td>5234917  </td><td> 774.2451</td><td>28.4561  </td><td>0.9935287</td><td>109.930  </td><td>32.364   </td><td>90.682   </td></tr>
	<tr><td>568367.9 </td><td>5224512  </td><td>1036.8050</td><td>17.6003  </td><td>0.2469274</td><td>100.680  </td><td>29.727   </td><td>97.864   </td></tr>
	<tr><td>571994.6 </td><td>5221844  </td><td>1714.9190</td><td>17.7117  </td><td>0.4574124</td><td>120.288  </td><td>27.524   </td><td>88.952   </td></tr>
</tbody>
</table>




```R
head(y,3)
```


<table>
<thead><tr><th>ABGR_BA</th><th>PIPO_BA</th><th>PSME_BA</th><th>THPL_BA</th><th>Total_BA</th></tr></thead>
<tbody>
	<tr><td> 0.00000 </td><td>0        </td><td>47.716568</td><td> 0.00000 </td><td>47.94183 </td></tr>
	<tr><td>20.90473 </td><td>0        </td><td> 1.382869</td><td>15.50835 </td><td>59.30739 </td></tr>
	<tr><td> 0.00000 </td><td>0        </td><td> 0.000000</td><td> 0.00000 </td><td>77.12319 </td></tr>
</tbody>
</table>



### Part 1
We start by building x and y data frames and running four alternative methods.



```R
mal <- yai(x = x, y = y, method = "mahalanobis")
 #summary(mal)
```


```R
msn <- yai(x = x, y = y, method = "msn")
# summary(msn)
```


```R
gnn <- yai(x = x, y = y, method = "gnn")
# summary(gnn)
```


```R
ica <- yai(x = x, y = y, method = "ica")
# summary(ica)
```

### Part 2
Method randomForest works best when there are few variables and when factors are used
rather than continuous variables. 

The `whatsMax` function is used to create a data frame of containing a list of the species of maximum basal area, and two other related variables.



```R
y2 <- cbind(whatsMax(y[, 1:4]), y[, 5])
names(y2) <- c("MajorSpecies", "BasalAreaMajorSp", "TotalBA")

```


```R
rf <- yai(x = x, y = y2, method = "randomForest")
head(y2)
```


<table>
<thead><tr><th>MajorSpecies</th><th>BasalAreaMajorSp</th><th>TotalBA</th></tr></thead>
<tbody>
	<tr><td>PSME_BA  </td><td>47.71657 </td><td>47.941832</td></tr>
	<tr><td>ABGR_BA  </td><td>20.90473 </td><td>59.307392</td></tr>
	<tr><td>zero     </td><td> 0.00000 </td><td>77.123193</td></tr>
	<tr><td>ABGR_BA  </td><td> 2.07906 </td><td> 3.740631</td></tr>
	<tr><td>ABGR_BA  </td><td>22.81478 </td><td>67.938562</td></tr>
	<tr><td>THPL_BA  </td><td>11.12922 </td><td>32.982188</td></tr>
</tbody>
</table>




```R
plot(rf)
```


![png](output_17_0.png)



```R
plot(rf, vars = yvars(rf))

```


![png](output_18_0.png)



```R
rfImp <- impute(rf, ancillaryData = y)
rmsd <- compare.yai(mal, msn, gnn, rfImp, ica)

```


```R
apply(rmsd, 2, mean, na.rm = TRUE)
plot(rmsd)
```


<dl class="dl-horizontal">
	<dt>mal.rmsdS</dt>
		<dd>1.11987085526243</dd>
	<dt>msn.rmsdS</dt>
		<dd>1.23707191100834</dd>
	<dt>gnn.rmsdS</dt>
		<dd>1.11426715966863</dd>
	<dt>rfImp.rmsdS</dt>
		<dd>1.0549175334721</dd>
	<dt>ica.rmsdS</dt>
		<dd>1.11987085526243</dd>
</dl>




![png](output_20_1.png)


### `AsciiGridImpute`


```R
data(MoscowMtStJoe)
# get the basal area by species columns
yba <- MoscowMtStJoe[,1:17]
ybaB <- whatsMax(yba,nbig=7) # see help on whatsMax


```


```R
ba <- cbind(ybaB,TotalBA=MoscowMtStJoe[,18])
x <- MoscowMtStJoe[,37:64]
x <- x[,-(4:5)]
rf <- yai(x=x,y=ba,method="randomForest")
yaiVarImp(rf)

```


![png](output_23_0.png)



```R
keep=colnames(yaiVarImp(rf,plot=FALSE,nTop=9))
newx <- x[,keep]
rf2 <- yai(x=newx,y=ba,method="randomForest")
yaiVarImp(rf2,col="gray")
compare.yai(rf,rf2)
```

    Warning message in compare.yai(rf, rf2):
    "not all scale factors are the same."


<table>
<thead><tr><th></th><th>rf.rmsdS</th><th>rf2.rmsdS</th></tr></thead>
<tbody>
	<tr><th>yba.maxVal</th><td>0.8292589</td><td>0.8235803</td></tr>
	<tr><th>TotalBA</th><td>0.6520216</td><td>0.6235289</td></tr>
	<tr><th>yba.maxCol</th><td>       NA</td><td>       NA</td></tr>
	<tr><th>EASTING</th><td>0.9520941</td><td>       NA</td></tr>
	<tr><th>NORTHING</th><td>0.9145283</td><td>       NA</td></tr>
	<tr><th>ELEVMEAN</th><td>0.7847333</td><td>       NA</td></tr>
	<tr><th>B1MEAN</th><td>0.8789015</td><td>       NA</td></tr>
	<tr><th>B2MEAN</th><td>0.7955657</td><td>       NA</td></tr>
	<tr><th>B3MEAN</th><td>0.6451351</td><td>       NA</td></tr>
	<tr><th>B4MEAN</th><td>0.6748496</td><td>0.7146684</td></tr>
	<tr><th>B5MEAN</th><td>0.8569372</td><td>       NA</td></tr>
	<tr><th>B6MEAN</th><td>0.8313746</td><td>       NA</td></tr>
	<tr><th>B7MEAN</th><td>0.6520053</td><td>       NA</td></tr>
	<tr><th>B8MEAN</th><td>0.7682170</td><td>       NA</td></tr>
	<tr><th>B9MEAN</th><td>0.8648000</td><td>       NA</td></tr>
	<tr><th>PANMEAN</th><td>0.6651546</td><td>0.6482123</td></tr>
	<tr><th>PANSTD</th><td>1.1287177</td><td>       NA</td></tr>
	<tr><th>INTMEAN</th><td>0.5514926</td><td>0.4617751</td></tr>
	<tr><th>INTSTD</th><td>0.6521839</td><td>       NA</td></tr>
	<tr><th>INTMIN</th><td>0.6179032</td><td>       NA</td></tr>
	<tr><th>INTMAX</th><td>0.9449718</td><td>       NA</td></tr>
	<tr><th>HTMEAN</th><td>0.4515395</td><td>0.2599951</td></tr>
	<tr><th>HTSTD</th><td>0.7884005</td><td>0.5237641</td></tr>
	<tr><th>HTMIN</th><td>0.4974160</td><td>0.3330944</td></tr>
	<tr><th>HTMAX</th><td>0.5752153</td><td>0.3485131</td></tr>
	<tr><th>CCMEAN</th><td>0.4541630</td><td>0.3972517</td></tr>
	<tr><th>CCSTD</th><td>0.7744999</td><td>       NA</td></tr>
	<tr><th>CCMIN</th><td>0.4218752</td><td>0.3890469</td></tr>
	<tr><th>CCMAX</th><td>0.6287315</td><td>       NA</td></tr>
</tbody>
</table>




![png](output_24_2.png)

